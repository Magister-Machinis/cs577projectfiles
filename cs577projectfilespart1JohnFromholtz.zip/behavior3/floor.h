#pragma once
class floor
{
private:
	int data;
public:
	void init()
	{
		this->data =0;
	}
	int get()
	{
		return this->data;
	}
	void set(int num)
	{
		this->data = num;
	}
};

